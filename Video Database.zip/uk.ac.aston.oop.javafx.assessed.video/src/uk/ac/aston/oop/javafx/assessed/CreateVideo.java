package uk.ac.aston.oop.javafx.assessed;

import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Slider;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import uk.ac.aston.oop.javafx.assessed.model.Database;
import uk.ac.aston.oop.javafx.assessed.model.Video;

public class CreateVideo {
	
	@FXML 
	private TextField title;
	
	@FXML 
	private TextField director;
	
	@FXML 
	private Slider playTime;
	
	@FXML 
	private TextArea comment;
	
	@FXML 
	private CheckBox checkBox;
	
	private Database item;
	
	public CreateVideo(Database item) {
		this.item = item;
	}

	@FXML
	public void cancelPressed() {
		comment.getScene().getWindow().hide();
	}

	@FXML
	public void createPressed() {
		Video video = new Video(title.getText(), director.getText(), (int) playTime.getValue());
		video.setComment(comment.getText());
		video.setOwn(checkBox.isSelected());
		item.addItem(video);
		title.getScene().getWindow().hide();
	}
}
